<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Casino</title>
    <link href="./hCgdEFEQLCzy/static/css/main.fc9f3533.chunk.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css"
        integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.touchswipe/1.6.4/jquery.touchSwipe.min.js"></script>
</head>

<body data-new-gr-c-s-check-loaded="14.984.0" data-gr-ext-installed="" cz-shortcut-listen="true">
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "sample";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM slider";
    $result = $conn->query($sql);

    ?>




    <div id="root" data-root="hCgdEFEQLCzy">
        <div class="casino-app">
            <div class="app-tabs tab_main">
                <button class="tab-link-active tab-link casino-tab" onclick="openPage('Casino', this, '#F0F0F0')"
                    id="defaultOpen">Casino</button><button class="tab-link offers-tab"
                    onclick="openPage('Offers', this, '#F0F0F0')">Offers</button><button class="tab-link vip-tab"
                    onclick="openPage('VIP', this, '#F0F0F0')">Vip</button><button class="tab-link pack-tab"
                    onclick="openPage('Packages', this, '#F0F0F0')">Packages</button><button class="tab-link play-tab"
                    onclick="openPage('PlaySlots', this, '#F0F0F0')">Play Slots</button>
<!-- Casino -->

<div id="Casino" class="tabcontent">
<div class="tab-content">
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <?php
    $sql = "SELECT * FROM slider";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $i=0;
        ?>
        <div class="carousel-inner" role="listbox">    
            <?php
            while($row = $result->fetch_assoc()) {
                if($i==0){
                    ?>
                    <div class="item active">
                        <img src="<?php echo "./img/".$row['simg']; ?>" width="100%">
                    </div>
                    <?php
                    $i=1;
                }else{
            ?>
            <div class="item">
                <a href="<?php echo $row['slink']?>" target="_blank">
                    <img alt="<?php echo "./img/".$row['simg']; ?>"
                        src="<?php echo "./img/".$row['simg']; ?>" width="100%">
                    <div class="carousel-caption"></div>
                </a>
            </div>
            <?php
                }
              }
            }
            ?>
        </div>
    </div>
</div>
                
<div class="casino-app">
    <div class="app-tabs undefined"><button class="tab-link-active sub_title">Best Online Casino
            Brands</button><button class="top_ten">Top 10</button></div>
    <div class="tab-content">
        <?php 
        $sql = "SELECT * FROM product WHERE cid=1";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            ?>
            <div class="content_div">
                <div class="content_fav"><img alt="#" src="<?php echo "./img/".$row['pimg']; ?>">
                </div>
                <div class="content_info"><span class="brand_label"><?php echo $row['pname']; ?></span><span
                        class="rating_star"><?php echo $row['prate'] ?>
                    </span><span class="bonus_offer_text" style="color:black;" ><?php echo $row['pdesc1'] ?></span></div>
                <div class="content_right"><span class="bonus_type">
                        <p><span style="color:#2ecc71">New Offer</span></p>
                    </span>
                    <a href ="<?php echo $row['plink'] ?>" style="text-decoration: none;"  target="_blank"> <div class="button_div">Play</div></a>
                    <div class="preview_button">Review Brand</div>
                </div>
            </div>
            <?php
            }
        } 
        ?>
    </div>
</div>
</div>

                <div id="Offers" class="tabcontent">
                    <div class="tab-content">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                        <?php
                          $sql = "SELECT * FROM slider";
                          $result = $conn->query($sql);
                        
                        if ($result->num_rows > 0) {
                            $i=0;
                        ?>
                        <div class="carousel-inner" role="listbox">    
                            <?php
                            while($row = $result->fetch_assoc()) {
                                if($i==0){
                                    ?>
                                    <div class="item active">
                                        <img src="<?php echo "./img/".$row['simg']; ?>" width="100%">
                                    </div>
                                    <?php
                                    $i=1;
                                }else{
                            ?>
                            <div class="item">
                                <a href="<?php echo $row['slink']?>" target="_blank">
                                    <img alt="<?php echo "./img/".$row['simg']; ?>"
                                        src="<?php echo "./img/".$row['simg']; ?>" width="100%">
                                    <div class="carousel-caption"></div>
                                </a>
                            </div>
                            <?php
                                }   
                            }
                            }
                            ?>
                            </div>
                        </div>
                    </div>

                    <div class="casino-app">
                        <div class="app-tabs undefined"><button class="tab-link-active sub_title">Best Online Casino
                                Brands</button><button class="top_ten">Top 10</button></div>
                        <div class="tab-content">
                        <?php 
        $sql = "SELECT * FROM product WHERE cid=2";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            ?>
            <div class="content_div">
                <div class="content_fav"><img alt="#" src="<?php echo "./img/".$row['pimg']?>">
                </div>
                <div class="content_info"><span class="brand_label"><?php echo $row['pname'] ?></span><span
                        class="rating_star"><?php echo $row['prate']; ?>
                    </span></div>
                <div class="content_right"><span class="bonus_type">
                        <p><span style="color:#2ecc71">New Offer</span></p>
                    </span>
                    <a href ="<?php echo $row['plink'] ?>" style="text-decoration: none;"  target="_blank"> <div class="button_div">Play</div></a>
                    <span class="bonus_offer_text"><?php echo $row['pdesc1'];?></span>
                </div>
            </div>
            <?php
            }
        } 
        ?>            
                        </div>
                    </div>

                </div>

                <div id="VIP" class="tabcontent">
                    <div class="tab-content">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                        <?php

$sql = "SELECT * FROM slider";
$result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            $i=0;
                            ?>
        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">    
            <?php
            while($row = $result->fetch_assoc()) {
                if($i==0){
                    ?>
                    <div class="item active">
                <img src="<?php echo "./img/".$row['simg']; ?>" width="100%">
            </div>
                    <?php
                    $i=1;
                }else{
            ?>
            <div class="item">
                <a href="<?php echo $row['slink']?>" target="_blank">
                    <img alt="<?php echo "./img/".$row['simg']; ?>"
                        src="<?php echo "./img/".$row['simg']; ?>" width="100%">
                    <div class="carousel-caption"></div>
                </a>
            </div>
            <?php
                }
                
              }
            }
            ?>
                            </div>
                        </div>
                    </div>

                    <div class="casino-app">
                        <div class="app-tabs undefined"><button class="tab-link-active sub_title">Best Online Casino
                                Brands</button><button class="top_ten">Top 10</button></div>
                        <div class="tab-content">
                        <?php 
        $sql = "SELECT * FROM product WHERE cid=3";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            ?>
                            <div class="content_div">
                                <div class="content_fav"><img alt="#" src="<?php echo "./img/".$row['pimg'];?>">
                                </div>
                                <div class="content_info"><span class="bonus_offer_text" style="color:black;">
                                <?php echo $row['pdesc1'];?></span><span class="rating_star"><?php echo $row['prate'];?></span><span
                                        class="brand_label"><?php echo $row['pname'];?></span></div>
                                <div class="content_right">
                                <a href= "<?php echo $row['plink'];?>"  style="text-decoration: none;"  target="_blank"><div class="yellow_play">Play</div></a><span class="minvip_deposit"> <?php echo $row['pdesc2'];?>
                                    </span><span class="minvip_deposit"><?php echo $row['pdesc3'];?></span>
                                </div>
                            </div>
                            <?php
        }
    }
        ?>
                        </div>
                    </div>

                </div>

                <div id="Packages" class="tabcontent">
                <?php 
        $sql = "SELECT * FROM product WHERE cid=4";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            ?>
                    <div class="package_content">
                        <div class="content_div">
                            <div class="content_round_fav"><img alt="#" src="<?php echo "./img/".$row['pimg'];?>">
                            </div>
                            <div class="content_info"><span class="brand_label"><?php echo $row['pname'];?></span></div>
                            <div class="content_right"><span class="rating_star"><?php echo $row['prate'];?></span></div>
                        </div>
                        <div class="fav_banner"><img alt="#" src="<?php echo "./img/".$row['pimg1'];?>">
                        </div>
                        <div class="row_reverse">
                        <a href= "<?php echo $row['plink'];?>"  style="text-decoration: none;"  target="_blank"><div class="button_div">Play</div></a>
                        </div>
                    </div>
                    <?php
                    }
                }
                    ?>
                </div>


                <div id="PlaySlots" class="tabcontent">
                    <div class="tab-content">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                        <?php
                        $sql = "SELECT * FROM slider";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            $i=0;
                            ?>
        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">    
            <?php
            while($row = $result->fetch_assoc()) {
                if($i==0){
                    ?>
                    <div class="item active">
                <img src="<?php echo "./img/".$row['simg']; ?>" width="100%">
            </div>
                    <?php
                    $i=1;
                }else{
            ?>
            <div class="item">
                <a href="<?php echo $row['slink']?>" target="_blank">
                    <img alt="<?php echo "./img/".$row['simg']; ?>"
                        src="<?php echo "./img/".$row['simg']; ?>" width="100%">
                    <div class="carousel-caption"></div>
                </a>
            </div>
            <?php
                }
                
              }
            }
            ?>
                            </div>
                        </div>
                    </div>

                    <div class="casino-app">
                        <div class="app-tabs undefined"><button class="tab-link-active sub_title">Best Online Casino
                                Brands</button><button class="top_ten">Top 10</button></div>
                        <div class="tab-content">
                        <?php 
                        $sql = "SELECT * FROM product WHERE cid=5";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            ?>
                            <div class="content_div">
                                <div class="content_fav"><img alt="#" src="<?php echo "./img/".$row['pimg'];?>">
                                </div>
                                <div class="content_info"><span class="brand_label" ><?php echo $row['pname'];?>
                                    </span><span style="color:black"><?php echo $row['pdesc1'];?></span></div>
                                <div class="content_right">
                                <a href= "<?php echo $row['plink'];?>"  style="text-decoration: none;"  target="_blank"><div class="button_div">Play</div></a>
                                    <div class="content_brand"><?php echo $row['pdesc2'];?></div>
                                </div>
                            </div>
                                <?php
                            }
                        }
        ?>
                        </div>
                    </div>

                </div>

            </div>
            <script>
            function openCity(evt, cityName) {
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tabcontent");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tablinks");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(cityName).style.display = "block";
                evt.currentTarget.className += " active";
            }
            </script>

            <script>
            function openPage(pageName, elmnt, color) {
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tabcontent");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tablink");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].style.backgroundColor = "";

                }
                document.getElementById(pageName).style.display = "block";
                elmnt.style.className = "tab-link-active pack-tab";
                elmnt.style.backgroundColor = color;
            }

            document.getElementById("defaultOpen").click();
            </script>
</body>

</html>